package com.masai.exceptions;

public class StudentException extends Exception{
	
	public StudentException() {
		// TODO Auto-generated constructor stub
	}
	
	public StudentException(String message) {
		super(message);
	}
	
	

}
